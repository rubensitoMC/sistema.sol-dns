#!/bin/bash

# Esto establece una varibale de entorno la cual indica que en la instalación de paquetes, no va a solicitar interacción del usuario, por ejemplo cuando nos pregunte si estamos seguros de algo yy podamos responder S/N

DEBIAN_FRONTEND=noninteractive

# Primero vamos a instalar las utilidades.

apt update -y

apt install bind9 bind9utils bind9-doc -y

# Como el archivo named y el archivo resolv.conf son iguales en ambas máquinas, no vamos a poner ninguna condición de hostname.
# Así que directamente lo copiamos en sus respectivos directorios.

cp /vagrant/machines/tierra/resolv.conf /etc/resolv.conf
cp /vagrant/machines/tierra/named /etc/default/named

# Ahora sí, la máquina tierra va a tener más archivos (aparte de que son diferentes los archivos de tierra y de venus) ya que es el servidor maestro, entonces tendremos que comprobar qué máquina es para instalar unos archivos u otros.

if [ $(cat /etc/hostname) == "tierra.sistema.sol" ]; then
    cp vagrant/machines/tierra/named.conf.local /etc/bind/named.conf.local
    cp vagrant/machines/tierra/named.conf.options /etc/bind/named.conf.options
    cp vagrant/machines/tierra/sistema.sol.dns /var/lib/bind
    cp vagrant/machines/tierra/sistema.sol.rev /var/lib/bind
else
    cp /vagrant/machines/venus/named.conf.options /etc/bind/named.conf.options
    cp /vagrant/machines/venus/named.conf.local /etc/bind/named.conf.local
fi

# Y ahora reinicamos el servicio.

sudo systemctl restart named